/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'Yek_Icons\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-arrow_down': '&#xe96b;',
		'icon-arrow_up': '&#xe96c;',
		'icon-Chortkeh': '&#xe96d;',
		'icon-camera': '&#xe96e;',
		'icon-icon-graph': '&#xe96f;',
		'icon-icon-leave': '&#xe970;',
		'icon-icon-user': '&#xe971;',
		'icon-minus': '&#xe972;',
		'icon-group': '&#xe973;',
		'icon-bank-1': '&#xe962;',
		'icon-cards': '&#xe963;',
		'icon-cards-1': '&#xe964;',
		'icon-home': '&#xe965;',
		'icon-home-1': '&#xe966;',
		'icon-profile-circle': '&#xe967;',
		'icon-profile-circle-1': '&#xe968;',
		'icon-repeat': '&#xe969;',
		'icon-repeat-1': '&#xe96a;',
		'icon-star': '&#xe960;',
		'icon-hugeicons_dress-06': '&#xe961;',
		'icon-book-saved': '&#xe947;',
		'icon-brush': '&#xe948;',
		'icon-brush-square': '&#xe949;',
		'icon-buildings': '&#xe94a;',
		'icon-car': '&#xe94b;',
		'icon-courthouse': '&#xe94c;',
		'icon-crown-2': '&#xe94d;',
		'icon-emoji-normal': '&#xe94e;',
		'icon-fluent_food-32-regular': '&#xe94f;',
		'icon-fluent_food-apple-24-regular': '&#xe950;',
		'icon-fluent_sport-soccer-24-regular': '&#xe951;',
		'icon-heart-circle': '&#xe952;',
		'icon-image': '&#xe953;',
		'icon-lamp': '&#xe954;',
		'icon-moneys': '&#xe955;',
		'icon-monitor': '&#xe956;',
		'icon-mouse': '&#xe957;',
		'icon-note-2': '&#xe958;',
		'icon-octicon_tools-24': '&#xe959;',
		'icon-pet': '&#xe95a;',
		'icon-shapes': '&#xe95b;',
		'icon-status-up': '&#xe95c;',
		'icon-tree': '&#xe95d;',
		'icon-truck': '&#xe95e;',
		'icon-wallet-check': '&#xe95f;',
		'icon-filter-filled': '&#xe946;',
		'icon-clock': '&#xe942;',
		'icon-calendar': '&#xe943;',
		'icon-chevron-left': '&#xe944;',
		'icon-transfer': '&#xe945;',
		'icon-autopayment_off': '&#xe940;',
		'icon-autopayment_on': '&#xe941;',
		'icon-cancel-fill': '&#xe93f;',
		'icon-alert-circle-fill': '&#xe93e;',
		'icon-fines': '&#xe93c;',
		'icon-recharge': '&#xe93d;',
		'icon-pdf': '&#xe93b;',
		'icon-edit-o': '&#xe93a;',
		'icon-bill': '&#xe936;',
		'icon-copy': '&#xe937;',
		'icon-gift': '&#xe938;',
		'icon-send-2': '&#xe939;',
		'icon-hidden': '&#xe934;',
		'icon-show': '&#xe935;',
		'icon-scanner': '&#xe933;',
		'icon-deposit-active': '&#xe931;',
		'icon-deposit-deactive': '&#xe932;',
		'icon-combo_box_arrow_up': '&#xe930;',
		'icon-Delete-fill': '&#xe92e;',
		'icon-Delete-outline': '&#xe92f;',
		'icon-alert': '&#xe929;',
		'icon-bank': '&#xe92a;',
		'icon-emoji-sad': '&#xe92b;',
		'icon-face-id': '&#xe92c;',
		'icon-fingerprint': '&#xe92d;',
		'icon-gallery': '&#xe927;',
		'icon-message-text': '&#xe928;',
		'icon-about': '&#xe913;',
		'icon-edit': '&#xe921;',
		'icon-heart': '&#xe922;',
		'icon-settings': '&#xe923;',
		'icon-card': '&#xe915;',
		'icon-Check': '&#xe916;',
		'icon-combo_box_arrow_down': '&#xe918;',
		'icon-Continue': '&#xe91a;',
		'icon-money': '&#xe91b;',
		'icon-receipt-list': '&#xe91d;',
		'icon-search': '&#xe91e;',
		'icon-solar_share-linear': '&#xe91f;',
		'icon-deposit': '&#xe91c;',
		'icon-shaba': '&#xe920;',
		'icon-message-question': '&#xe914;',
		'icon-tick': '&#xe912;',
		'icon-Hidden_num': '&#xe900;',
		'icon-Kartable': '&#xe911;',
		'icon-Done': '&#xe904;',
		'icon-Filter': '&#xe901;',
		'icon-Add': '&#xe902;',
		'icon-Left-arrow': '&#xe903;',
		'icon-info': '&#xe905;',
		'icon-Warning': '&#xe906;',
		'icon-Hidden': '&#xe907;',
		'icon-Notif': '&#xe908;',
		'icon-Copy': '&#xe909;',
		'icon-Cancel': '&#xe90a;',
		'icon-Right_arrow': '&#xe90b;',
		'icon-Add_bank': '&#xe90c;',
		'icon-Logout': '&#xe90d;',
		'icon-Refresh': '&#xe90e;',
		'icon-Update': '&#xe90f;',
		'icon-Menu': '&#xe910;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
