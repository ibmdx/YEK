/* To avoid CSS expressions while still supporting IE 7 and IE 6, use this script */
/* The script tag referencing this file must be placed before the ending body tag. */

/* Use conditional comments in order to target IE 7 and older:
	<!--[if lt IE 8]><!-->
	<script src="ie7/ie7.js"></script>
	<!--<![endif]-->
*/

(function() {
	function addIcon(el, entity) {
		var html = el.innerHTML;
		el.innerHTML = '<span style="font-family: \'Yek_Icons\'">' + entity + '</span>' + html;
	}
	var icons = {
		'icon-filter-filled': '&#xe946;',
		'icon-clock': '&#xe942;',
		'icon-calendar': '&#xe943;',
		'icon-chevron-left': '&#xe944;',
		'icon-transfer': '&#xe945;',
		'icon-autopayment_off': '&#xe940;',
		'icon-autopayment_on': '&#xe941;',
		'icon-cancel-fill': '&#xe93f;',
		'icon-alert-circle-fill': '&#xe93e;',
		'icon-fines': '&#xe93c;',
		'icon-recharge': '&#xe93d;',
		'icon-pdf': '&#xe93b;',
		'icon-edit-o': '&#xe93a;',
		'icon-bill': '&#xe936;',
		'icon-copy': '&#xe937;',
		'icon-gift': '&#xe938;',
		'icon-send-2': '&#xe939;',
		'icon-hidden': '&#xe934;',
		'icon-show': '&#xe935;',
		'icon-scanner': '&#xe933;',
		'icon-deposit-active': '&#xe931;',
		'icon-deposit-deactive': '&#xe932;',
		'icon-combo_box_arrow_up': '&#xe930;',
		'icon-Delete-fill': '&#xe92e;',
		'icon-Delete-outline': '&#xe92f;',
		'icon-alert': '&#xe929;',
		'icon-bank': '&#xe92a;',
		'icon-emoji-sad': '&#xe92b;',
		'icon-face-id': '&#xe92c;',
		'icon-fingerprint': '&#xe92d;',
		'icon-gallery': '&#xe927;',
		'icon-message-text': '&#xe928;',
		'icon-about': '&#xe913;',
		'icon-edit': '&#xe921;',
		'icon-heart': '&#xe922;',
		'icon-settings': '&#xe923;',
		'icon-card': '&#xe915;',
		'icon-Check': '&#xe916;',
		'icon-combo_box_arrow_down': '&#xe918;',
		'icon-Continue': '&#xe91a;',
		'icon-money': '&#xe91b;',
		'icon-receipt-list': '&#xe91d;',
		'icon-search': '&#xe91e;',
		'icon-solar_share-linear': '&#xe91f;',
		'icon-deposit': '&#xe91c;',
		'icon-shaba': '&#xe920;',
		'icon-message-question': '&#xe914;',
		'icon-tick': '&#xe912;',
		'icon-Hidden_num': '&#xe900;',
		'icon-Kartable': '&#xe911;',
		'icon-Done': '&#xe904;',
		'icon-Filter': '&#xe901;',
		'icon-Add': '&#xe902;',
		'icon-Left-arrow': '&#xe903;',
		'icon-info': '&#xe905;',
		'icon-Warning': '&#xe906;',
		'icon-Hidden': '&#xe907;',
		'icon-Notif': '&#xe908;',
		'icon-Copy': '&#xe909;',
		'icon-Cancel': '&#xe90a;',
		'icon-Right_arrow': '&#xe90b;',
		'icon-Add_bank': '&#xe90c;',
		'icon-Logout': '&#xe90d;',
		'icon-Refresh': '&#xe90e;',
		'icon-Update': '&#xe90f;',
		'icon-Menu': '&#xe910;',
		'0': 0
		},
		els = document.getElementsByTagName('*'),
		i, c, el;
	for (i = 0; ; i += 1) {
		el = els[i];
		if(!el) {
			break;
		}
		c = el.className;
		c = c.match(/icon-[^\s'"]+/);
		if (c && icons[c[0]]) {
			addIcon(el, icons[c[0]]);
		}
	}
}());
